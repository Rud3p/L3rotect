from setuptools import setup, find_packages

setup(
    name='L3rotect',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'random',
        'time',
        'psutil',
        'ctypes',
        'platform',
        'os',
        're',
        'uuid',
        'wmi',
        'requests',
        'subprocess',
        'urllib3',
    ],
)
